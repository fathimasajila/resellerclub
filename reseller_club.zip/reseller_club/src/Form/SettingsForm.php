<?php

namespace Drupal\reseller_club\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Link;
use Drupal\Core\Url;

/**
 * Provides a form for administering disable messages.
 */
class SettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'reseller_club_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->config('reseller_club.settings')
      ->set('reseller_username', $form_state->getValue('reseller_username'))
      ->set('reseller_password', $form_state->getValue('reseller_password'))
      ->set('reseller_email', $form_state->getValue('reseller_email'))
      ->set('reseller_api_key', $form_state->getValue('reseller_api_key'))
      ->set('reseller_id', $form_state->getValue('reseller_id'))
      ->set('reseller_customer_id', $form_state->getValue('reseller_customer_id'))
      ->set('reseller_contact_id', $form_state->getValue('reseller_contact_id'))
      ->set('reseller_name_servers', $form_state->getValue('reseller_name_servers'))
      ->set('reseller_request_url', $form_state->getValue('reseller_request_url'))
      ->set('tour_server_ip', $form_state->getValue('tour_server_ip'))
      ->save();

    parent::submitForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form = array();

    $form['reseller_username'] = array(
      '#type' => 'textfield',
      '#title' => t('Reseller Username'),
      '#description' => t('Enter reseller username'),
      '#default_value' => \Drupal::config('reseller_club.settings')->get('reseller_username'),
    );

    $form['reseller_password'] = array(
      '#type' => 'password',
      '#title' => t('Reseller Password'),
      '#description' => t('Enter reseller password'),
      '#default_value' => \Drupal::config('reseller_club.settings')->get('reseller_password'),
    );

    $form['reseller_email'] = array(
      '#type' => 'textfield',
      '#title' => t('Reseller Email'),
      '#size' => 40,
      '#default_value' => \Drupal::config('reseller_club.settings')->get('reseller_email'),
      '#description' => t('Enter email id registered with reseller account.'),
    );

    $form['reseller_api_key'] = array(
      '#type' => 'textfield',
      '#title' => t('Reseller API key'),
      '#description' => t('Enter reseller API key'),
      '#default_value' => \Drupal::config('reseller_club.settings')->get('reseller_api_key'),
    );

    $form['reseller_id'] = array(
      '#type' => 'textfield',
      '#title' => t('Reseller ID'),
      '#description' => t('Enter reseller ID'),
      '#default_value' => \Drupal::config('reseller_club.settings')->get('reseller_id'),
    );

    $form['reseller_customer_id'] = array(
      '#type' => 'textfield',
      '#title' => t('Customer ID'),
      '#description' => t('Enter Customer ID'),
      '#default_value' => \Drupal::config('reseller_club.settings')->get('reseller_customer_id'),
    );

    $form['reseller_contact_id'] = array(
      '#type' => 'textfield',
      '#title' => t('Customer contact ID'),
      '#description' => t('Enter contact id'),
      '#default_value' => \Drupal::config('reseller_club.settings')->get('reseller_contact_id'),
    );

    $form['reseller_name_servers'] = array(
      '#type' => 'textfield',
      '#title' => t('Name servers'),
      '#description' => t('Enter name servers'),
      '#default_value' => \Drupal::config('reseller_club.settings')->get('reseller_name_servers'),
    );

    $form['reseller_request_url'] = array(
      '#type' => 'textfield',
      '#title' => t('Request URL'),
      '#description' => t('Enter request url'),
      '#default_value' => \Drupal::config('reseller_club.settings')->get('reseller_request_url'),
    );

    $form['tour_server_ip'] = array(
      '#type' => 'textfield',
      '#title' => t('Tour server ip address'),
      '#description' => t('Enter tour server ip address.'),
      '#default_value' => \Drupal::config('reseller_club.settings')->get('tour_server_ip'),
    );

    $form['#submit'][] = 'reseller_club_settings_form_submit';
    return parent::buildForm($form, $form_state);
  }


  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'reseller_club.settings',
    ];
  }

}
