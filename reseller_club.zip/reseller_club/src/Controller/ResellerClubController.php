<?php
namespace Drupal\reseller_club\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Component\Serialization\Json;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use GuzzleHttp\Pool;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\Component\Utility\Unicode;


/**
 * Controller routines for reseller routes.
 */
class ResellerClubController extends ControllerBase {

  /**
   * Callback to check domain avaliable or not.
   */
  public function resellerClubDomainAvailable() {
    $httpClient = \Drupal::httpClient();

    $apiUrl = \Drupal::config('reseller_club.settings')->get('reseller_request_url');
    $resellerId = \Drupal::config('reseller_club.settings')->get('reseller_id');
    $apiKey = \Drupal::config('reseller_club.settings')->get('reseller_api_key');
    $domainName = \Drupal::request()->request->get('domain_name');
    $domain_tlds = \Drupal::request()->request->get('domain_tlds');
    $domain = $domainName . '.' . $domain_tlds;

    $httpRequestUrl = $apiUrl . '/api/domains/available.json?auth-userid=' . $resellerId . '&api-key=' . $apiKey . '&domain-name=' . $domainName . '&tlds=com&tlds=net&tlds=us&tlds=org&tlds=biz&tlds=info&tlds=ws';

    $request = $httpClient->get($httpRequestUrl, ['timeout' => 1000]);
    $response = Json::decode($request->getBody());
    \Drupal::logger('domain_available')->notice(print_r($response, TRUE));
    $domainArray = [];
    foreach ($response as $key => $res) {
      if ($domain === $key) {
        if ($res['status'] !== 'available') {
          echo 'not available'; exit;
        }
        $domainArray[$key]['status'] = $res['status'];
      } else {
        if ($res['status'] == 'available') {
          $domainArray[$key]['status'] = $res['status'];
        }
      }
    }

    $domainInfo = Json::encode($domainArray);
    print $domainInfo; exit;
  }

  /**
   * Function to register a domain in resellerclub.
   */
  public function resellerClubDomainRegister() {
    $httpClient = \Drupal::httpClient();

    $apiUrl = \Drupal::config('reseller_club.settings')->get('reseller_request_url');
    $resellerId = \Drupal::config('reseller_club.settings')->get('reseller_id');
    $apiKey = \Drupal::config('reseller_club.settings')->get('reseller_api_key');
    $customerId = \Drupal::config('reseller_club.settings')->get('reseller_customer_id');
    $contactId = \Drupal::config('reseller_club.settings')->get('reseller_contact_id');
    $ns_data = \Drupal::config('reseller_club.settings')->get('reseller_name_servers');
    $ns_data = explode(',', $ns_data);

    $ns1 = trim($ns_data[0]);
    $ns2 = trim($ns_data[1]);

    $contacthash = array(
      'registrantcontactid' => $contactId,
      'admincontactid' => $contactId,
      'technicalcontactid' => $contactId,
      'billingcontactid' => $contactId
    );

    $domain_name =  \Drupal::request()->request->get('domain_name');
    $domain_tlds =  \Drupal::request()->request->get('domain_tlds');
    $domain = trim($domain_name) . '.' . $domain_tlds;
    if (!$this->isValidDomain($domain)) {
      print 'Not a valid domain name'; exit;
    }

    $domain_list[$domain] = 1;
    $invoiceOption = 'KeepInvoice';

    try {
      /*$domainRegisterRequest = $httpClient->post($apiUrl . '/api/domains/register.xml', [
        'form_params' => [
          'auth-userid' => $resellerId,
          'api-key' => $apiKey,
          'domain-name' => strtolower($domain),
          'years' => $domain_list[$domain],
          'ns' => $ns1,
          'ns' => $ns2,
          'customer-id' => $customerId,
          'reg-contact-id' => $contacthash["registrantcontactid"],
          'admin-contact-id' => $contacthash["admincontactid"],
          'tech-contact-id' => $contacthash["technicalcontactid"],
          'billing-contact-id' => $contacthash["billingcontactid"],
          'invoice-option' => $invoiceOption,
          'protect-privacy' => 'false',
        ],
        'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
      ]);

      $domainStatus = $domainRegisterRequest->getStatusCode();*/
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $apiUrl . '/api/domains/register.xml');
  curl_setopt($ch, CURLOPT_VERBOSE, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

  curl_setopt($ch, CURLOPT_POST,TRUE);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

  // Set the request as a POST FIELD for curl.
  curl_setopt($ch, CURLOPT_POSTFIELDS, 'auth-userid=' . $resellerId . '&api-key=' . $apiKey . '&domain-name='.strtolower($domain).'&years='.$domain_list[$domain].'&ns='.$ns1.'&ns='.$ns2.'&customer-id=' . $customerId . '&reg-contact-id='.$contacthash["registrantcontactid"].'&admin-contact-id='.$contacthash["admincontactid"].'&tech-contact-id='.$contacthash["technicalcontactid"].'&billing-contact-id='.$contacthash["billingcontactid"].'&invoice-option='.$invoiceOption.'&protect-privacy=false');

  $httpResponse = curl_exec($ch);
  //('Success','utf-8');
  \Drupal::logger('domain_register')->notice($httpResponse);
  $response = preg_replace('/\s+/S', " ", $httpResponse);
  \Drupal::logger('domain_register0')->notice($response);
  $returnvalue = explode('status', $response);
  \Drupal::logger('domain_register_explode')->notice(print_r($returnvalue[1], true));
  $message = sprintf($returnvalue[1]);
  $message = preg_replace('!\s+!', '', $message);

  \Drupal::logger('domain_register1')->notice($message);

      if(strlen($message) == 56) {
        $orderId = $this->resellerOrderId($domain);
      }
      else {
        \Drupal::logger('domain_register2')->notice($returnvalue[1]);
        echo 'error';
        exit;
      }

      if($orderId) {
        $dnsActivateStatus = $this->dnsZoneActivate($orderId);
      } else {
        \Drupal::logger('domain_register')->notice('Failed');
        echo 'error';
        exit;
      }

      if($dnsActivateStatus == 200) {
        $addressRecord = $this->addAddressRecord($domain);
        $cnameRecord = $this->addCnameRecord($domain);
      } else {
        \Drupal::logger('domain_activation')->notice('Failed');
        echo 'error';
        exit;
      }

      if ($addressRecord == 200 && $cnameRecord == 200) {
        echo 'success';
        exit;
      } else {
        \Drupal::logger('domain_dns')->notice('Failed');
        echo 'error';
        exit;
      }

    } catch (RequestException $e) {
      echo 'error';
      exit;
    }
  }

  /**
   * Function to add C-Name Record.
   */
  public function addCnameRecord($domain) {
    $httpClient = \Drupal::httpClient();

    $apiUrl = \Drupal::config('reseller_club.settings')->get('reseller_request_url');
    $resellerId = \Drupal::config('reseller_club.settings')->get('reseller_id');
    $apiKey = \Drupal::config('reseller_club.settings')->get('reseller_api_key');

    try {
      $httpCnameRecord = $httpClient->post($apiUrl . '/api/dns/manage/add-cname-record.json', [
        'form_params' => [
          'auth-userid' => $resellerId,
          'api-key' => $apiKey,
          'host' => 'www',
          'domain-name' => $domain,
          'value' => $domain,
        ],
        'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
      ]);
      return $httpCnameRecord->getStatusCode();
    } catch (RequestException $e) {
      return FALSE;
    }
  }

  /**
   * Function to add A-Record for the domain.
   */
  public function addAddressRecord($domain) {
    $httpClient = \Drupal::httpClient();

    $apiUrl = \Drupal::config('reseller_club.settings')->get('reseller_request_url');
    $resellerId = \Drupal::config('reseller_club.settings')->get('reseller_id');
    $apiKey = \Drupal::config('reseller_club.settings')->get('reseller_api_key');
    $serverIp = \Drupal::config('reseller_club.settings')->get('tour_server_ip');

    try {
      $httpAddressRecord = $httpClient->post($apiUrl . '/api/dns/manage/add-ipv4-record.json', [
        'form_params' => [
          'auth-userid' => $resellerId,
          'api-key' => $apiKey,
          'domain-name' => $domain,
          'value' => $serverIp,
        ],
        'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
      ]);
      return $httpAddressRecord->getStatusCode();
    } catch (RequestException $e) {
      return FALSE;
    }
  }

  /**
   * Function to fetch reseller order id.
   */
  public function resellerClubOrderId($domain) {
    $httpClient = \Drupal::httpClient();

    $apiUrl = \Drupal::config('reseller_club.settings')->get('reseller_request_url');
    $resellerId = \Drupal::config('reseller_club.settings')->get('reseller_id');
    $apiKey = \Drupal::config('reseller_club.settings')->get('reseller_api_key');

    try {
      $httpRequestUrl = $apiUrl . '/api/domains/details-by-name.json?auth-userid=' . $resellerId . '&api-key=' . $apiKey . '&domain-name=' . strtolower($domain) . '&options=OrderDetails';
      $requestOrderDetails = $httpClient->get($httpRequestUrl);
      $orderDetails = $requestOrderDetails->getBody();

      $orderDetails = json_decode($orderDetails);
      return $orderDetails->orderid;
    }
    catch (RequestException $e) {
      return FALSE;
    }
    catch (\GuzzleHttp\Exception\ServerException $e) {
      return FALSE;
    }
  }

  /**
   * Activate DNS Zone Service.
   */
  public function dnsZoneActivate($orderId) {
    $httpClient = \Drupal::httpClient();

    $apiUrl = \Drupal::config('reseller_club.settings')->get('reseller_request_url');
    $resellerId = \Drupal::config('reseller_club.settings')->get('reseller_id');
    $apiKey = \Drupal::config('reseller_club.settings')->get('reseller_api_key');
    

    try {
      $httpActivateDns = $httpClient->post($apiUrl . '/api/dns/activate.xml', [
        'form_params' => [
          'auth-userid' => $resellerId,
          'api-key' => $apiKey,
          'order-id' => $orderId,
        ],
        'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
      ]);
      return $httpActivateDns->getStatusCode();
    } catch (RequestException $e) {
      return FALSE;
    }
  }
  
  /**
   * To get the domain expiratin date.
   * @param
   *   domain_name: requested domain name.
   *  @return status of the api call.
   */
  public function domainExpirationDate($domain) {
    $httpClient = \Drupal::httpClient();

    $apiUrl = \Drupal::config('reseller_club.settings')->get('reseller_request_url');
    $resellerId = \Drupal::config('reseller_club.settings')->get('reseller_id');
    $apiKey = \Drupal::config('reseller_club.settings')->get('reseller_api_key');

    try {
      $httpRequestUrl = $apiUrl . '/api/domains/details-by-name.json?auth-userid=' . $resellerId . '&api-key=' . $apiKey . '&domain-name=' . strtolower($domain) . '&options=OrderDetails';
      $requestOrderDetails = $httpClient->get($httpRequestUrl);
      $orderDetails = $requestOrderDetails->getBody();

      $orderDetails = json_decode($orderDetails);
      return $orderDetails->endtime;
    }
    catch (RequestException $e) {
      return FALSE;
    }
    catch (\GuzzleHttp\Exception\ServerException $e) {
      return FALSE;
    }
  }

  /**
   * Check domain is valid.
   */
  public function isValidDomain($domain) {
    if (!preg_match("/^([-a-z0-9]{2,100})\.([a-z\.]{2,8})$/i", $domain)) {
      return FALSE;
    }
    return TRUE;
  }

}
